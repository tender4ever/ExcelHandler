﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExcelDriver;

namespace ExcelHandlerTester
{
    class Program
    {
        static void Main(string[] args)
        {
            Program aProgram = new Program();

            aProgram.ExcelHandler1();
        }


        private void ExcelHandler1()
        {
            ExcelHandler1 aExcelHandler1 = new ExcelHandler1(@"\\10.96.40.46\d$\Tender\test.xls", 1);

            aExcelHandler1.Read("1","1");

            aExcelHandler1.Wirte("1","1","test");

            aExcelHandler1.Close();
        }
    }
}
